from Algorithm import QueuesLinkedList
from queues import *
from TrafficLight import *
from QueuesLinkedList import *

aLight = TrafficLight()
queues = queues.

class RoadRunnable:
    def __init__(self,roadNumber, aLight):
        self.roadNumber = roadNumber
        self.aLight = aLight

    def run(self):
        while QueuesLinkedList.QueuesLinked.isempty()!=0:
            aLight.turngreenon(self.roadNumber)
            QueuesLinkedList.QueuesLinked.dequeue()

    def add(self,car=""):
        for i in range(1,10):

            # QueuesLinkedList.QueuesLinked.enqueue(car)









