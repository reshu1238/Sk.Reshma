A = [63,250,835,947,651,28]
print('Original List:', A)
A.sort()
print('Sorted List:', A)

A = [63,250,835,947,651,28]
print('Original List:', A)
B = sorted(A)
print('List-A:', A)
print('List-B:', B)

A = [63,250,835,947,651,28]
print('Original List:', A)
A.sort(reverse=True)
print('Sorted List:', A)


